﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour {

	
	// Use this for initialization
	void Start () {
		max = + 1);
		int max = 1000;
		int min = 1;
		int guess 500;

		void Start() { 

		print ("Welcome To Number Wizard");	
		print ("Pick a number in your head, but dont tell me!" );

		int max = 1000;
		int min = 1;

	print ("The higest number you can pick is "   +max);
	print ("The lowest numer you can pick is " + min);

	print ("Is the number higher or lower than" + guess?);	
	print ("Up arrow = higher, down = lower, return = equal");
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.UpArrow)) {
			print ("Up Arrow pressed");
			min = guess;
			guess = (max + min) / 2;
			print ("Higher or lower than'" + guess);

		} else if (Input.GetKeyDown (KeyCode.DownArrow)) {
			print ("Down Arrow pressed"):
		} else if (Input.GetKeyDown (KeyCode.Return)) {
			print ("I won");

			print ("Up Arrow pressed");
			min = guess;
			guess = (max + min) / 2;
			print ("Higher or lower than'" + guess);

		} else if (Input.GetKeyDown (KeyCode.DownArrow)) {
			print ("Down Arrow pressed"):
		} else if (Input.GetKeyDown (KeyCode.Return)) {
			print ("I won");

			print ("Up Arrow pressed");
			min = guess;
			guess = (max + min) / 2;
			print ("Higher or lower than'" + guess);

		} else if (Input.GetKeyDown (KeyCode.DownArrow)) {
			print ("Down Arrow pressed"):
		} else if (Input.GetKeyDown (KeyCode.Return)) {
			print ("I won");
}

	}

		
	}

